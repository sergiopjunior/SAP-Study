import com.sap.it.api.mapping.*;
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

// Add MappingContext parameter to read or set headers and properties
static def String customFunc1(String P1,String P2,MappingContext context) {
         String value1 = context.getHeader(P1);
         String value2 = context.getProperty(P2);
         return value1+value2;
}

// Add Output parameter to assign the output value.
static def void custFunc2(String[] is,String[] ps, Output output, MappingContext context) {
        String value1 = context.getHeader(is[0]);
        String value2 = context.getProperty(ps[0]);
        output.addValue(value1);
        output.addValue(value2);
}

def String posix_to_iso_date(String timestamp){
    if (timestamp == null) {
        return '0000-00-00 00.00.00.00000 +0000';
    }
    try {
        return new Date(Long.valueOf(timestamp)).format("yyyy-MM-dd HH.mm.ss.SSSSS Z");
    }
	catch (Exception ex) {
        return '0000-00-00 00.00.00.00000 +0000';
    }
}

static def convert_version_to_int(Message message) {
    def body = new JsonSlurper().parseText(message.getBody(java.lang.String))
    body["fields"].description.version = Integer.valueOf(body["fields"].description.version)


    message.setBody(JsonOutput.toJson(body))
    return message
}