import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

static def get_unreferenced_tasks(Object body) {
    def filter =  body["tasks"].findAll{
        task -> task["custom_fields"].find{
            field -> field["name"] == "TaskReferenceUrl" &&
                    !field["value"]
        }
    }
    return filter
}

static def get_tasks_to_create(Message message) {
    def body = new JsonSlurper().parseText(message.getBody(java.lang.String))
    def filtered_tasks = get_unreferenced_tasks(body)

    def results = [
            tasks: filtered_tasks
    ]
    message.setBody(JsonOutput.toJson(results))
    return message
}

static def get_referenced_tasks(Object body) {
    def filter =  body["tasks"].findAll{
        task -> task["custom_fields"].find{
            field -> field["name"] == "TaskReferenceUrl" &&
                    field["value"]
        }
    }
    return filter
}

static def get_tasks_to_update(Message message) {
    def body = new JsonSlurper().parseText(message.getBody(java.lang.String))
    def filtered_tasks = get_referenced_tasks(body)

    def results = [
            tasks: filtered_tasks
    ]
    message.setBody(JsonOutput.toJson(results))
    return message
}